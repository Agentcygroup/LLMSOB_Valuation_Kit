#include <iostream>
#include <vector>
#include <complex>
#include <Eigen/Dense>
#include <random>
#include <memory>
#include <fstream>
#include <string>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

using Complex = std::complex<double>;
using ComplexVector = Eigen::VectorXcd;
using ComplexMatrix = Eigen::MatrixXcd;

class IoTSensorStream {
private:
    size_t dim;
    std::vector<double> last_measurements;
    std::vector<std::vector<double>> historical_data;

public:
    IoTSensorStream(size_t dim, size_t historical_timesteps) : dim(dim), last_measurements(dim) {
        historical_data.resize(historical_timesteps, std::vector<double>(dim));
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_real_distribution<> dis(0.0, 1.0);
        for (auto& timestep : historical_data) {
            for (auto& val : timestep) val = dis(gen);
        }
        for (auto& val : last_measurements) val = dis(gen);
    }

    std::vector<double> get_measurements(size_t t) {
        std::random_device rd;
        std::mt19937 gen(rd());
        std::normal_distribution<> noise(0.0, 0.0001);
        auto historical = historical_data[t % historical_data.size()];
        for (size_t i = 0; i < dim; ++i) {
            last_measurements[i] = 0.95 * last_measurements[i] + 0.05 * historical[i] + noise(gen);
            last_measurements[i] = std::max(0.0, std::min(1.0, last_measurements[i]));
        }
        return last_measurements;
    }
};

class TwinContainer {
private:
    size_t id;
    std::shared_ptr<IoTSensorStream> sensor_stream;

public:
    TwinContainer(size_t id, size_t dim, size_t num_sub_simulations)
        : id(id), sensor_stream(std::make_shared<IoTSensorStream>(dim, 1000000)) {}

    std::vector<double> get_data() const {
        return sensor_stream->get_measurements(0);
    }

    size_t get_id() const { return id; }
};

class TwinPipeline {
private:
    std::vector<std::shared_ptr<TwinContainer>> containers;
    std::ofstream data_log;
    std::ofstream benchmark_log;
    std::vector<std::string> frameworks;
    size_t matrix_dim;

public:
    TwinPipeline(const std::string& log_file, const std::string& benchmark_file,
                 const std::vector<std::string>& frameworks, size_t matrix_dim)
        : data_log(log_file), benchmark_log(benchmark_file), frameworks(frameworks), matrix_dim(matrix_dim) {}

    void add_container(std::shared_ptr<TwinContainer> container) {
        containers.push_back(container);
    }

    void run_pipeline(double t0, double tf, double dt) {
        for (double t = t0; t <= tf; t += dt) {
            for (auto& container : containers) {
                auto data = container->get_data();
                data_log << "Container " << container->get_id() << " at t=" << t << ": ";
                for (const auto& val : data) data_log << val << " ";
                data_log << "\n";
            }
        }
        benchmark_log << "Pipeline completed for frameworks: ";
        for (const auto& fw : frameworks) benchmark_log << fw << " ";
        benchmark_log << "\n";
    }

    std::vector<std::vector<double>> get_data() {
        std::vector<std::vector<double>> all_data;
        for (const auto& container : containers) {
            all_data.push_back(container->get_data());
        }
        return all_data;
    }
};

PYBIND11_MODULE(digital_twin, m) {
    pybind11::class_<IoTSensorStream>(m, "IoTSensorStream")
        .def(pybind11::init<size_t, size_t>())
        .def("get_measurements", &IoTSensorStream::get_measurements);

    pybind11::class_<TwinContainer>(m, "TwinContainer")
        .def(pybind11::init<size_t, size_t, size_t>())
        .def("get_data", &TwinContainer::get_data)
        .def("get_id", &TwinContainer::get_id);

    pybind11::class_<TwinPipeline>(m, "TwinPipeline")
        .def(pybind11::init<const std::string&, const std::string&, const std::vector<std::string>&, size_t>())
        .def("add_container", &TwinPipeline::add_container)
        .def("run_pipeline", &TwinPipeline::run_pipeline)
        .def("get_data", &TwinPipeline::get_data);
}
