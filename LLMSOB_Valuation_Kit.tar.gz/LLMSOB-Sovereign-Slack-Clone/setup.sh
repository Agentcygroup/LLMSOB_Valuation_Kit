#!/usr/bin/env bash
set -euo pipefail
IFS=$'\n\t'

# Define project root
PROJECT_ROOT="/Users/agentcy_group_miami/LLMSOB-Sovereign-Slack-Clone"
cd "$PROJECT_ROOT"

# Load .env
source .env

# Install dependencies (macOS arm64)
echo "Installing dependencies..."
brew install python@3.11 git docker k3s kubectl helm neo4j cmake libomp eigen || true

# Setup k3s
if ! pgrep k3s &>/dev/null; then
  echo "Starting k3s..."
  sudo k3s server --disable-agent &
  sleep 10
  export KUBECONFIG=/etc/rancher/k3s/k3s.yaml
  sudo chmod 644 /etc/rancher/k3s/k3s.yaml
else
  echo "k3s already running"
  export KUBECONFIG=/etc/rancher/k3s/k3s.yaml
fi

# Setup Python virtual environment
VENV="/Users/agentcy_group_miami/LLMSOB-Sovereign-Slack-Clone/venv"
echo "Setting up Python virtual environment..."
python3.11 -m venv "$VENV"
source "$VENV/bin/activate"
pip install --upgrade pip setuptools wheel
pip install -r requirements.txt

# Compile C++ digital twin
echo "Compiling C++ digital twin..."
mkdir -p build
cd build
cmake .. -DCMAKE_BUILD_TYPE=Release -DEIGEN3_INCLUDE_DIR=/opt/homebrew/include/eigen3
make
cp digital_twin.so ../quantum/
cd ..

# Deploy services
echo "Deploying services..."
helm repo add mattermost https://helm.mattermost.com
helm repo add n8n https://helm.n8n.io
helm repo add gitlab https://charts.gitlab.io
helm repo add nextcloud https://nextcloud.github.io/helm
helm repo add neo4j https://helm.neo4j.com/neo4j
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo add grafana https://grafana.github.io/helm-charts
helm repo add bitnami https://charts.bitnami.com/bitnami
helm repo update

kubectl create namespace llmsob || true
helm install mattermost mattermost/mattermost --namespace llmsob --set service.port=${MATTERMOST_PORT} --set service.type=NodePort
helm install n8n n8n/n8n --namespace llmsob --set service.port=${N8N_PORT} --set service.type=NodePort
helm install gitlab gitlab/gitlab --namespace llmsob --set global.hosts.domain=localhost --set global.hosts.externalIP=0.0.0.0 --set service.port=${GITLAB_PORT} --set service.type=NodePort
helm install nextcloud nextcloud/nextcloud --namespace llmsob --set service.port=${NEXTCLOUD_PORT} --set service.type=NodePort
helm install neo4j neo4j/neo4j --namespace llmsob --set neo4j.password=${NEO4J_AUTH} --set service.port=${NEO4J_PORT} --set service.type=NodePort
helm install prometheus prometheus-community/prometheus --namespace llmsob --set service.port=${PROMETHEUS_PORT} --set service.type=NodePort
helm install grafana grafana/grafana --namespace llmsob --set service.port=${GRAFANA_PORT} --set service.type=NodePort
helm install keycloak bitnami/keycloak --namespace llmsob --set auth.adminUser=${KEYCLOAK_ADMIN} --set auth.adminPassword=${KEYCLOAK_ADMIN_PASSWORD} --set service.type=NodePort

# Deploy ArgoCD
echo "Deploying ArgoCD..."
kubectl apply -n llmsob -f manifests/argocd/install.yaml

# Wait for services
echo "Waiting for services to start..."
sleep 30

# Setup Git SSH
if [[ ! -f ~/.ssh/id_rsa ]]; then
  echo "Setting up SSH key..."
  ssh-keygen -t rsa -b 4096 -C "agentcy_group_miami@Dannys-MacBook-Pro.local" -f ~/.ssh/id_rsa -N ""
  echo "Add this SSH public key to GitHub[](https://github.com/settings/keys):"
  cat ~/.ssh/id_rsa.pub
fi

# Clone repos
REPOS=("git@github.com:Agentcygroup/quantum-swarm-gapfill.git" "git@github.com:Agentcygroup/agentcy_group_miami_2025.git")
for repo in "${REPOS[@]}"; do
  name=$(basename "$repo" .git)
  clone_dir="/Users/agentcy_group_miami/LLMSOB-Sovereign-Slack-Clone/repos/$name"
  mkdir -p "$clone_dir"
  git clone "$repo" "$clone_dir" || true
done

# Commit initial setup
git add .
git commit -m "Initial setup of LLMSOB Sovereign Slack Clone" || true
git remote add origin git@github.com:Agentcygroup/llmsob-sovereign-slack-clone.git || true
git push -u origin main || true

echo "✅ Deployed! Access:"
echo " • Mattermost: http://localhost:${MATTERMOST_PORT}"
echo " • Marketplace: http://localhost:${NEXTCLOUD_PORT}/marketplace"
echo " • GitLab: http://localhost:${GITLAB_PORT}"
echo " • Neo4j: http://localhost:${NEO4J_PORT}"
echo " • Grafana: http://localhost:${GRAFANA_PORT} (admin/admin)"
echo " • Weaviate: http://localhost:${WEAVIATE_PORT}"
echo " • Mosquitto: mqtt://localhost:${MOSQUITTO_PORT}"
