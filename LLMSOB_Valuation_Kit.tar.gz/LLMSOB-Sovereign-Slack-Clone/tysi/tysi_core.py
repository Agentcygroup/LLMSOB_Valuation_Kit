from fastapi import FastAPI
from neo4j import GraphDatabase

app = FastAPI()
driver = GraphDatabase.driver("bolt://neo4j:7687", auth=("neo4j", "pass"))

@app.post("/tysi")
async def tysi_generate(idea: str):
    with driver.session() as session:
        session.run("CREATE (n:Idea {text: })", idea=idea)
    return {"result": f"Generated code for: {idea}"}
